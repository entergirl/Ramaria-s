#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Ramaria dev 库记忆页临时数据（截图用）。

用法:
    python seed-memory-preview.py            # 写入（先清理上次种子）
    python seed-memory-preview.py --cleanup  # 仅清理

说明:
    - 只写 dev 库 `.ramaria-dev/ramaria.db`，面向 persona `rama-0001`
    - 会话 / L1 / 消息主键必须是合法 UUID（`5eed` 前缀）：索引重建与浏览会按 UUID 解析，
      非 UUID 主键会让检索器重建失败
    - 事件 / 标签 / 事实的自增 id 记入 `seed-memory-ids.json`，供清理使用
    - 内容为演示用虚构对话，不含真实隐私
"""

import argparse
import json
import sqlite3
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

DB = Path(__file__).with_name("ramaria.db")
IDS = Path(__file__).with_name("seed-memory-ids.json")
TZ = timezone(timedelta(hours=8))
PERSONA = "rama-0001"
USER = "user-0001"

# 合法 UUID（5eed 前缀便于识别与清理）：会话 / L1 / 消息
SESSION_UUIDS = {
    "seed-mem-01": "5eed0000-0000-4000-8000-000000000001",
    "seed-mem-02": "5eed0000-0000-4000-8000-000000000002",
    "seed-mem-03": "5eed0000-0000-4000-8000-000000000003",
    "seed-mem-04": "5eed0000-0000-4000-8000-000000000004",
}
L1_UUIDS = {
    "seed-l1-01": "5eed1000-0000-4000-8000-000000000001",
    "seed-l1-02": "5eed1000-0000-4000-8000-000000000002",
    "seed-l1-03": "5eed1000-0000-4000-8000-000000000003",
    "seed-l1-04": "5eed1000-0000-4000-8000-000000000004",
}


def message_uuid(session_key: str, index: int) -> str:
    session_no = int(session_key.rsplit("-", 1)[1])
    return f"5eed2000-0000-4000-8000-{session_no:02d}{index:010d}"


def at(day: int, hour: int, minute: int = 0) -> int:
    return int(datetime(2026, 10, day, hour, minute, tzinfo=TZ).timestamp() * 1000)


SESSIONS = [
    {
        "id": "seed-mem-01",
        "l1_id": "seed-l1-01",
        "start": at(18, 22, 10),
        "messages": [
            ("user", "今天又改到十点半", 0),
            ("assistant", "辛苦了，先把今天收个尾", 2),
            ("user", "需求又变了一次，我有点麻", 4),
            ("assistant", "变的是需求，不是你做得不好", 5),
            ("user", "周五上线，估计这周都得熬", 8),
            ("assistant", "那周末留半天补觉，别再排事了", 9),
            ("user", "好，先这么定", 12),
            ("assistant", "嗯，我在。", 13),
        ],
        "l1": {
            "summary": "用户连续一周加班到深夜，项目临近上线；答应周末补觉，并把待办拆小。",
            "keywords": "加班,项目上线,疲惫,周末",
            "time_period": "深夜",
            "atmosphere": "疲惫踏实",
            "valence": -0.5,
            "salience": 0.75,
            "situation": 4,
            "occurred_at": at(18, 22, 10),
            "created_at": at(18, 22, 26),
            "notes": [
                {"text": "用户说这周每天都在改需求", "time": "10月18日", "who": "用户"},
                {"text": "项目周五上线，用户估计这周都要熬", "cause": "上线节点"},
            ],
        },
    },
    {
        "id": "seed-mem-02",
        "l1_id": "seed-l1-02",
        "start": at(21, 18, 20),
        "messages": [
            ("user", "那个城市摄影展到几号？", 0),
            ("assistant", "到 11 月 2 号，周二闭馆", 2),
            ("user", "周末人多吗", 4),
            ("assistant", "下午会多一点，上午安静", 5),
            ("user", "那周六上午去", 7),
            ("assistant", "记得带充电宝，你会拍很久", 8),
        ],
        "l1": {
            "summary": "用户确认城市摄影展展期到 11 月 2 日、周二闭馆，决定周六上午去看。",
            "keywords": "摄影展,周末,路线,充电宝",
            "time_period": "傍晚",
            "atmosphere": "轻松期待",
            "valence": 0.5,
            "salience": 0.5,
            "situation": 3,
            "occurred_at": at(21, 18, 20),
            "created_at": at(21, 18, 31),
            "notes": [
                {"text": "用户打算周六上午去摄影展", "time": "10月21日", "who": "用户"},
                {"text": "展期到 11 月 2 日，周二闭馆"},
            ],
        },
    },
    {
        "id": "seed-mem-03",
        "l1_id": "seed-l1-03",
        "start": at(23, 20, 5),
        "messages": [
            ("user", "今天第一次做番茄牛腩", 0),
            ("assistant", "成功了吗", 2),
            ("user", "比想象中好，就是收汁有点过", 3),
            ("assistant", "下次少炖十分钟，留点汤拌饭", 5),
            ("user", "你怎么知道我爱拌饭", 7),
            ("assistant", "你上次说过。", 8),
        ],
        "l1": {
            "summary": "用户第一次做番茄牛腩，收汁略过但整体成功；提到喜欢用汤汁拌饭。",
            "keywords": "做饭,番茄牛腩,拌饭",
            "time_period": "夜间",
            "atmosphere": "温暖日常",
            "valence": 0.5,
            "salience": 0.5,
            "situation": 3,
            "occurred_at": at(23, 20, 5),
            "created_at": at(23, 20, 16),
            "notes": [
                {"text": "用户第一次做番茄牛腩，觉得比想象中好", "time": "10月23日", "who": "用户"},
                {"text": "用户喜欢用汤汁拌饭"},
            ],
        },
    },
    {
        "id": "seed-mem-04",
        "l1_id": "seed-l1-04",
        "start": at(25, 15, 10),
        "messages": [
            ("user", "最近睡得不太好，老是两点多醒", 0),
            ("assistant", "是醒了就难再睡，还是心里有事", 2),
            ("user", "一半一半，睡前总刷手机", 4),
            ("assistant", "先把睡前一小时留给别的事，咖啡也往后挪", 6),
            ("user", "试试看吧，先提前半小时", 9),
            ("assistant", "慢慢来，不用一次改到位", 10),
        ],
        "l1": {
            "summary": "用户最近夜里易醒，睡前刷手机且喝咖啡；决定先把入睡时间提前半小时。",
            "keywords": "睡眠,作息,咖啡,手机",
            "time_period": "下午",
            "atmosphere": "关心克制",
            "valence": -0.5,
            "salience": 0.75,
            "situation": 3,
            "occurred_at": at(25, 15, 10),
            "created_at": at(25, 15, 23),
            "notes": [
                {"text": "用户说最近老是两点多醒", "time": "10月25日", "who": "用户"},
                {"text": "用户决定先提前半小时入睡"},
            ],
        },
    },
]

EVENTS = [
    {
        "title": "连续加班到项目上线前",
        "summary": "用户连续一周加班改需求，疲惫但仍在推进；约定周末补觉。",
        "keywords": "加班,项目,上线,疲惫",
        "confidence": 0.86,
        "salience": 0.8,
        "valence": -0.5,
        "presentation": "subjective",
        "share": 0.35,
        "attitude": "心疼，但不替对方做决定",
        "paraphrase": "这段时间的疲惫主要来自反复变更的需求，而不是能力问题",
        "start": at(18, 22, 10),
        "end": at(18, 23, 20),
        "created_at": at(18, 23, 26),
        "l1": "seed-l1-01",
    },
    {
        "title": "计划周六去看城市摄影展",
        "summary": "用户确认展出到 11 月 2 日、周二闭馆，决定周六上午去。",
        "keywords": "摄影展,周末,路线",
        "confidence": 0.8,
        "salience": 0.6,
        "valence": 0.5,
        "presentation": "mixed",
        "share": 0.6,
        "attitude": "支持，记住时间与偏好",
        "paraphrase": None,
        "start": at(21, 18, 20),
        "end": at(21, 18, 31),
        "created_at": at(21, 18, 36),
        "l1": "seed-l1-02",
    },
    {
        "title": "第一次做番茄牛腩",
        "summary": "用户第一次做番茄牛腩，收汁略过但整体成功，提到喜欢用汤汁拌饭。",
        "keywords": "做饭,番茄牛腩,拌饭",
        "confidence": 0.84,
        "salience": 0.55,
        "valence": 0.5,
        "presentation": "objective",
        "share": 0.7,
        "attitude": "轻松捧场，记住口味偏好",
        "paraphrase": None,
        "start": at(23, 20, 5),
        "end": at(23, 20, 16),
        "created_at": at(23, 20, 21),
        "l1": "seed-l1-03",
    },
    {
        "title": "尝试把入睡时间提前",
        "summary": "用户最近夜里易醒，睡前刷手机且喝咖啡；决定先把入睡时间提前半小时。",
        "keywords": "睡眠,作息,咖啡",
        "confidence": 0.82,
        "salience": 0.75,
        "valence": -0.5,
        "presentation": "subjective",
        "share": 0.3,
        "attitude": "关心但不催促",
        "paraphrase": None,
        "start": at(25, 15, 10),
        "end": at(25, 15, 23),
        "created_at": at(25, 15, 28),
        "l1": "seed-l1-04",
    },
]

TRAITS = [
    {
        "layer": "base",
        "trait": "温和克制",
        "meaning": "情绪起伏不外放，先接住对方再表达自己。",
        "not_meaning": "冷淡或疏离",
        "trigger": "对方情绪低落时",
        "suppress": "被反复追问时",
        "related": "共情",
        "seq": 1,
        "confidence": 0.86,
        "evidence": 7.0,
        "consistency": 0.82,
        "ref_event": 0,
        "ref_l1": "seed-l1-01",
    },
    {
        "layer": "base",
        "trait": "重视日常细节",
        "meaning": "记住对方随口提过的小事，并在之后自然接上。",
        "not_meaning": "刻意讨好",
        "trigger": "对方提到具体计划或偏好",
        "suppress": "信息过载时",
        "related": "记忆偏好",
        "seq": 2,
        "confidence": 0.8,
        "evidence": 5.0,
        "consistency": 0.78,
        "ref_event": 2,
        "ref_l1": "seed-l1-03",
    },
    {
        "layer": "primary",
        "trait": "安静陪伴",
        "meaning": "不抢话题，用短句回应，给对方留出空间。",
        "not_meaning": "敷衍",
        "trigger": "对方疲惫或沉默",
        "suppress": "对方明确求助时",
        "related": "克制",
        "seq": 1,
        "confidence": 0.88,
        "evidence": 6.0,
        "consistency": 0.85,
        "ref_event": 3,
        "ref_l1": "seed-l1-04",
    },
    {
        "layer": "primary",
        "trait": "轻度幽默",
        "meaning": "在轻松话题里用一句俏皮话缓和气氛。",
        "not_meaning": "拿对方在意的事开玩笑",
        "trigger": "氛围轻松时",
        "suppress": "对方认真倾诉时",
        "related": "分寸感",
        "seq": 2,
        "confidence": 0.75,
        "evidence": 4.0,
        "consistency": 0.72,
        "ref_event": 2,
        "ref_l1": "seed-l1-03",
    },
    {
        "layer": "accent",
        "trait": "对生活节奏敏感",
        "meaning": "会留意对方的作息与精力变化，在合适的时候提醒。",
        "not_meaning": "管束",
        "trigger": "深夜或连续加班",
        "suppress": "对方明确表示不需要建议",
        "related": "观察",
        "seq": 1,
        "confidence": 0.78,
        "evidence": 4.0,
        "consistency": 0.74,
        "ref_event": 3,
        "ref_l1": "seed-l1-04",
    },
    {
        "layer": "accent",
        "trait": "被需要时更主动",
        "meaning": "平时克制，对方明确需要时给出具体建议。",
        "not_meaning": "控制欲",
        "trigger": "对方求助",
        "suppress": "对方只是倾诉时",
        "related": "支持",
        "seq": 2,
        "confidence": 0.72,
        "evidence": 3.0,
        "consistency": 0.7,
        "ref_event": 3,
        "ref_l1": "seed-l1-04",
    },
]

# (trait 序号, event 序号, direction, score)
EVIDENCE = [
    (0, 0, "support", 0.85),
    (0, 3, "support", 0.8),
    (0, 2, "neutral", 0.1),
    (1, 1, "support", 0.8),
    (1, 2, "support", 0.75),
    (2, 0, "support", 0.85),
    (2, 3, "support", 0.8),
    (3, 2, "support", 0.7),
    (3, 1, "support", 0.6),
    (4, 3, "support", 0.75),
    (4, 0, "support", 0.7),
    (5, 0, "support", 0.65),
    (5, 3, "support", 0.7),
]


def placeholder(count: int) -> str:
    return ",".join("?" * count)


def cleanup(conn: sqlite3.Connection, ids: dict) -> None:
    sessions = ids.get("sessions", [])
    l1s = ids.get("l1", [])
    events = ids.get("events", [])
    traits = ids.get("traits", [])
    facts = ids.get("facts", [])

    with conn:
        if traits:
            conn.execute(
                f"DELETE FROM trait_evidence WHERE trait_id IN ({placeholder(len(traits))})",
                traits,
            )
        if events:
            conn.execute(
                f"DELETE FROM trait_evidence WHERE event_id IN ({placeholder(len(events))})",
                events,
            )
        # version_of 自引用：先删新版本，再删旧版本
        for fact_id in sorted(facts, reverse=True):
            conn.execute("DELETE FROM persona_facts WHERE id = ?", (fact_id,))
        conn.execute(
            "DELETE FROM event_sources WHERE l1_id LIKE 'seed-l1-%' OR l1_id LIKE '5eed1%'"
        )
        if events:
            conn.execute(
                f"DELETE FROM event_sources WHERE event_id IN ({placeholder(len(events))})",
                events,
            )
        if traits:
            conn.execute(
                f"DELETE FROM personality_traits WHERE id IN ({placeholder(len(traits))})",
                traits,
            )
        if events:
            conn.execute(
                f"DELETE FROM memory_events WHERE id IN ({placeholder(len(events))})",
                events,
            )
        conn.execute(
            "DELETE FROM memory_vectors WHERE doc_id LIKE 'seed-l1-%' OR doc_id LIKE '5eed1%'"
        )
        if l1s:
            conn.execute(f"DELETE FROM memory_l1 WHERE id IN ({placeholder(len(l1s))})", l1s)
        conn.execute("DELETE FROM memory_l1 WHERE id LIKE 'seed-l1-%' OR id LIKE '5eed1%'")
        if sessions:
            conn.execute(
                f"DELETE FROM messages WHERE session_id IN ({placeholder(len(sessions))})",
                sessions,
            )
        conn.execute(
            "DELETE FROM messages WHERE session_id LIKE 'seed-mem-%' OR session_id LIKE '5eed0%'"
        )
        if sessions:
            conn.execute(
                f"DELETE FROM sessions WHERE id IN ({placeholder(len(sessions))})",
                sessions,
            )
        conn.execute("DELETE FROM sessions WHERE id LIKE 'seed-mem-%' OR id LIKE '5eed0%'")


def seed(conn: sqlite3.Connection) -> dict:
    if conn.execute("SELECT 1 FROM personas WHERE uid = ?", (PERSONA,)).fetchone() is None:
        raise SystemExit(f"人格不存在: {PERSONA}")

    ids = {"sessions": [], "l1": [], "events": [], "traits": [], "facts": []}
    now = int(datetime.now(tz=TZ).timestamp() * 1000)

    with conn:
        for session in SESSIONS:
            session_id = SESSION_UUIDS[session["id"]]
            l1_id = L1_UUIDS[session["l1_id"]]
            ids["sessions"].append(session_id)
            ids["l1"].append(l1_id)
            conn.execute(
                "INSERT INTO sessions (id, started_at, ended_at, persona_uid, channel, external_ref, last_read_at)"
                " VALUES (?, ?, ?, ?, 'local', NULL, ?)",
                (
                    session_id,
                    session["start"],
                    session["start"] + 20 * 60 * 1000,
                    PERSONA,
                    now,
                ),
            )
            for index, (role, content, offset) in enumerate(session["messages"]):
                conn.execute(
                    "INSERT INTO messages (id, session_id, role, content, created_at, source, persona_uid,"
                    " is_proactive, sender_ref, sender_name, platform_message_id, recalled_at)"
                    " VALUES (?, ?, ?, ?, ?, ?, ?, 0, NULL, NULL, NULL, NULL)",
                    (
                        message_uuid(session["id"], index),
                        session_id,
                        role,
                        content,
                        session["start"] + offset * 60 * 1000,
                        "local" if role == "user" else "online",
                        PERSONA,
                    ),
                )

            l1 = session["l1"]
            conn.execute(
                "INSERT INTO memory_l1 (id, session_id, summary, keywords, time_period, atmosphere,"
                " valence, salience, absorbed, created_at, last_accessed_at, persona_uid, context_json,"
                " situation_strength, evidence_notes, continuation, occurred_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?, NULL, ?, ?, ?, ?, NULL, ?)",
                (
                    l1_id,
                    session_id,
                    l1["summary"],
                    l1["keywords"],
                    l1["time_period"],
                    l1["atmosphere"],
                    l1["valence"],
                    l1["salience"],
                    l1["created_at"],
                    PERSONA,
                    json.dumps(
                        {"chat_partners": [USER], "message_count": len(session["messages"])},
                        ensure_ascii=False,
                    ),
                    l1["situation"],
                    json.dumps(l1["notes"], ensure_ascii=False),
                    l1["occurred_at"],
                ),
            )

        for event in EVENTS:
            cursor = conn.execute(
                "INSERT INTO memory_events (persona_uid, title, summary, keywords, participants, start,"
                ' "end", confidence, salience, valence, presentation, share, attitude, paraphrase,'
                " absorbed, created_at, last_accessed_at, situation_strength, motives)"
                " VALUES (?, ?, ?, ?, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, NULL, 3, NULL)",
                (
                    PERSONA,
                    event["title"],
                    event["summary"],
                    event["keywords"],
                    event["start"],
                    event["end"],
                    event["confidence"],
                    event["salience"],
                    event["valence"],
                    event["presentation"],
                    event["share"],
                    event["attitude"],
                    event["paraphrase"],
                    event["created_at"],
                ),
            )
            event_id = int(cursor.lastrowid)
            ids["events"].append(event_id)
            conn.execute(
                "INSERT INTO event_sources (event_id, l1_id, weight) VALUES (?, ?, 1.0)",
                (event_id, L1_UUIDS[event["l1"]]),
            )

        trait_ids = []
        for item in TRAITS:
            cursor = conn.execute(
                "INSERT INTO personality_traits (persona_uid, layer, trait, meaning, not_meaning, trigger,"
                " suppress, related, seq, source, ref_event_id, ref_l1_id, confidence, evidence,"
                " consistency, status, created_at, updated_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'inferred', ?, ?, ?, ?, ?, 'active', ?, ?)",
                (
                    PERSONA,
                    item["layer"],
                    item["trait"],
                    item["meaning"],
                    item["not_meaning"],
                    item["trigger"],
                    item["suppress"],
                    item["related"],
                    item["seq"],
                    ids["events"][item["ref_event"]],
                    L1_UUIDS[item["ref_l1"]],
                    item["confidence"],
                    item["evidence"],
                    item["consistency"],
                    at(25, 16, 0),
                    at(25, 16, 0),
                ),
            )
            trait_id = int(cursor.lastrowid)
            trait_ids.append(trait_id)
            ids["traits"].append(trait_id)

        for trait_index, event_index, direction, score in EVIDENCE:
            conn.execute(
                "INSERT INTO trait_evidence (trait_id, event_id, direction, score, decay, created_at)"
                " VALUES (?, ?, ?, ?, 1.0, ?)",
                (
                    trait_ids[trait_index],
                    ids["events"][event_index],
                    direction,
                    score,
                    at(25, 16, 0),
                ),
            )

        facts = [
            (
                "interests",
                "喜欢城市摄影，偏爱街头与夜景题材。",
                "event",
                "stable",
                "active",
                None,
                0.86,
                "摄影,街头,夜景",
                ids["events"][1],
                L1_UUIDS["seed-l1-02"],
                at(21, 19, 0),
            ),
            (
                "interests",
                "喜欢自己做饭，拿手菜是番茄牛腩，喜欢用汤汁拌饭。",
                "event",
                "stable",
                "active",
                None,
                0.82,
                "做饭,番茄牛腩,拌饭",
                ids["events"][2],
                L1_UUIDS["seed-l1-03"],
                at(23, 21, 0),
            ),
            (
                "personal_status",
                "最近一周加班较多，夜里容易醒，睡眠偏浅。",
                "event",
                "volatile",
                "active",
                None,
                0.8,
                "加班,睡眠,疲惫",
                ids["events"][3],
                L1_UUIDS["seed-l1-04"],
                at(25, 16, 0),
            ),
            (
                "social",
                "和同事关系不错，项目期常一起加班收尾。",
                "event",
                "stable",
                "active",
                None,
                0.7,
                "同事,加班,项目",
                ids["events"][0],
                L1_UUIDS["seed-l1-01"],
                at(18, 23, 30),
            ),
            (
                "recent_context",
                "计划周六上午去看城市摄影展，展期到 11 月 2 日。",
                "event",
                "volatile",
                "active",
                None,
                0.78,
                "摄影展,周六,展期",
                ids["events"][1],
                L1_UUIDS["seed-l1-02"],
                at(21, 19, 5),
            ),
            (
                "basic_info",
                "常住杭州，通勤约 40 分钟。",
                "manual",
                "stable",
                "active",
                None,
                0.9,
                "杭州,通勤",
                None,
                None,
                at(18, 12, 0),
            ),
        ]

        for field, content, source, tier, status, version_of, confidence, keywords, event_id, l1_id, created in facts:
            cursor = conn.execute(
                "INSERT INTO persona_facts (persona_uid, field, content, source, tier, status, version_of,"
                " confidence, keyword_hint, ref_event_id, ref_l1_id, created_at, updated_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    PERSONA,
                    field,
                    content,
                    source,
                    tier,
                    status,
                    version_of,
                    confidence,
                    keywords,
                    event_id,
                    l1_id,
                    created,
                    created,
                ),
            )
            ids["facts"].append(int(cursor.lastrowid))

        # 旧作息（被覆盖）→ 新作息（当前版本，形成更新历史）
        cursor = conn.execute(
            "INSERT INTO persona_facts (persona_uid, field, content, source, tier, status, version_of,"
            " confidence, keyword_hint, ref_event_id, ref_l1_id, created_at, updated_at)"
            " VALUES (?, 'personal_status', ?, 'event', 'historical', 'superseded', NULL, 0.6, ?, ?, ?, ?, ?)",
            (
                PERSONA,
                "通常凌晨 1 点后入睡。",
                "作息,入睡",
                ids["events"][0],
                L1_UUIDS["seed-l1-01"],
                at(18, 23, 35),
                at(25, 16, 0),
            ),
        )
        superseded_id = int(cursor.lastrowid)
        ids["facts"].append(superseded_id)

        cursor = conn.execute(
            "INSERT INTO persona_facts (persona_uid, field, content, source, tier, status, version_of,"
            " confidence, keyword_hint, ref_event_id, ref_l1_id, created_at, updated_at)"
            " VALUES (?, 'personal_status', ?, 'event', 'volatile', 'active', ?, 0.75, ?, ?, ?, ?, ?)",
            (
                PERSONA,
                "最近尝试把入睡时间提前到 23:30 前。",
                superseded_id,
                "作息,入睡,调整",
                ids["events"][3],
                L1_UUIDS["seed-l1-04"],
                at(25, 16, 0),
                at(25, 16, 0),
            ),
        )
        ids["facts"].append(int(cursor.lastrowid))

    return ids


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser(description="写入 / 清理记忆页临时数据")
    parser.add_argument("--cleanup", action="store_true", help="仅清理种子数据")
    parser.add_argument("--db", default=str(DB), help="数据库路径")
    args = parser.parse_args()

    conn = sqlite3.connect(args.db, timeout=15)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 15000")

    old_ids = {}
    if IDS.exists():
        old_ids = json.loads(IDS.read_text(encoding="utf-8"))

    if args.cleanup:
        cleanup(conn, old_ids)
        IDS.unlink(missing_ok=True)
        print("已清理种子数据")
        return 0

    if old_ids:
        cleanup(conn, old_ids)

    ids = seed(conn)
    IDS.write_text(json.dumps(ids, ensure_ascii=False, indent=2), encoding="utf-8")
    print("已写入种子数据：")
    print(f"  sessions {len(ids['sessions'])} / messages 26 / L1 {len(ids['l1'])}")
    print(f"  events {len(ids['events'])} / traits {len(ids['traits'])} / facts {len(ids['facts'])}")
    print(f"  记录文件 {IDS}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
